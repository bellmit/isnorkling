package isnork.g9.utils.risk;

public class IndividualRiskProfile {
	// private int distance;
	private double riskAvoidance;
	// private double clustering;
//	public void setDistanceToExplore(int d) {
//		distance = d;
//	}
//	public int getDistanceToExplore() { return distance; }
	
	public void setRiskAvoidance(double a) {
		this.riskAvoidance = a;
	}
	public double getRiskAvoidance() { return riskAvoidance; }
	
//	public void setClustering(double c) {
//		clustering = c;
//	}
//	public double getClustering() { return clustering; }
}
