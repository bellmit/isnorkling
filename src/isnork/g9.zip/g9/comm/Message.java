package isnork.g9.comm;

public interface Message {

}
