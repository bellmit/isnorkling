package isnork.g9.strategy;

import isnork.sim.GameObject.Direction;

import java.awt.geom.Point2D;

public class ObservationWrapper {
	public int happiness;
	public Direction direction;
	public Point2D location;
	public int id;
}